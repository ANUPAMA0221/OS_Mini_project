#include<stdio.h>

float mini[10];		//array to store all avg waiting times and avg turnaround times

// avg waiting times are stored in even indices of the array
// avg turnaround times are stored in odd indices of the array


	// func for first-come,first-served algo
void fcfs(int n,int at[], int bt[]){
  int a_t[10],at2[10], b_t[10], wt[10],tat[10],ex[100],seq[100],re[100],avwt=0,avtat=0;
  int i,j,start,pos,max=0,min,idle=0,k=0;
   wt[0]=0;   
 
  for(i=0;i<n;i++){
	b_t[i]=bt[i];
 	a_t[i]=at[i];
 	at2[i]=at[i];
    }
 	start=at[0];
    for(i=1;i<n;i++)
    {
      if(start>at[i])
       {
       start=at[i];
       }
    }
    printf("\nSequence of execution for fcfs	:\n");
    for(i=0;i<n;i++)
    {
    if(max<at[i])
     {
      max=at[i];
     }
    }
    max=max+1;
   for(i=0;i<n;i++,k++)
     {  min=max;
       for(j=0;j<n;j++){  
           if(at[j]!=-1)
             {
               if(at[j]<min)
                 {
                  min=at[j];
                  pos=j;
                 }
              }
         }
      printf("[P%d]  ",pos+1);
      seq[k]=pos;
      if(start<at[pos]){
         re[pos]=start;
         idle+=at[pos]-start;
         start=at[pos];
         start+=bt[pos];
         at[pos]=-1;
         ex[pos]=start;
      }
      else{
        re[pos]=start;
        start+=bt[pos];
        at[pos]=-1;
        ex[pos]=start;
       }
    }
    printf("\n");
    for(i=0;i<n;i++)
    {
       tat[i]=ex[i]-at2[i];
       wt[i]=tat[i]-bt[i];
    }
 printf("\n\n~Process~ ~ArrivalTime~    ~BurstTime~   ~WaitingTime~  ~TuraroundTime~\n\n");
   for(i=0;i<n;i++)
    {
      printf("P[%d]\t\t%d\t\t%d\t\t%d\t\t%d\n",i+1,at2[i],bt[i],wt[i],tat[i]);
    }
   for(i=0;i<n;i++)
   {
    avwt+=wt[i];
    avtat+=tat[i];
   }
   avwt=(float)avwt/n;
   avtat=(float)avtat/n;
   mini[0]=avwt;
   mini[1]=avtat;
   printf("\n\nAverage Waiting Time:%d",avwt);
   printf("\nAverage Turnaround Time:%d",avtat);
  
   for(i=0;i<n;i++){
 	bt[i]=b_t[i];
 	at[i]=a_t[i];
	}
}

		//func for Shortest job first algo
void sjf(int n, int bt[]){
	int b_t[10],p[10],wt[10],tat[10],i,j,total=0,total2=0,pos,temp;
	float avg_wt,avg_tat;
	for(i=0;i<n;i++){
 		b_t[i]=bt[i];
 	}
 
 	for(i=0;i<n;i++){
 		p[i]=i+1;
 	}
 	for(i=0;i<n;i++){
 		pos=i;
 		for(j=i+1;j<n;j++)
 		{
 			if(bt[j]<bt[pos])
 				pos=j;
 		}
 		temp=bt[i];
 		bt[i]=bt[pos];
 		bt[pos]=temp;
 		temp=p[i];
 		p[i]=p[pos]; 
 		p[pos]=temp;
 	}
 	wt[0]=0;
 	for(i=1;i<n;i++){
 		wt[i]=0;
 		for(j=0;j<i;j++)
 		{
 			wt[i]+=bt[j];
 		}
 		total+=wt[i];
 	}
 	avg_wt=(float)total/n;
 	total=0;
 	printf("\n~Process~\t~BurstTime~\t~WaitingTime~\t~TurnaroundTime~");
 	for(i=0;i<n;i++){
 		tat[i]=bt[i]+wt[i];
 		total2+=tat[i];
 		printf("\np%d\t\t %d\t\t %d\t\t\t%d",p[i],bt[i],wt[i],tat[i]);
 	}
 	avg_tat=(float)total2/n;
 	printf("\n\nAverage Waiting Time=%f",avg_wt);
 	printf("\nAverage Turnaround Time=%f\n",avg_tat);
 	mini[2]=avg_wt;
 	mini[3]=avg_tat;
 	for(i=0;i<n;i++){
 		bt[i]=b_t[i];
 	}
}

		//func for Round Robin algo
void rr(int n,int at[],int bt[],int tq){
	int b_t[10],a_t[10],cnt,i,j,time,remain,flag=0; 
 	int wait_time=0,turnaround_time=0,rt[10]; 
 	float Avg_wt,Avg_tat;
 	remain=n;
 
 	for(i=0;i<n;i++){
 		b_t[i]=bt[i];
 		a_t[i]=at[i];
 	}
  
 	for(cnt=0;cnt<n;cnt++) 
 	{ 
 		rt[cnt]=bt[cnt]; 
 	} 
 
 	printf("\n\n~Process~ ~BurstTime~ ~TurnaroundTime~ ~WaitingTime~\n\n"); 
 	for(time=0,cnt=0;remain!=0;)
 	{ 
 		if(rt[cnt]<=tq && rt[cnt]>0) 
 		{ 
 			time+=rt[cnt]; 
			rt[cnt]=0; 
 			flag=1; 
 		} 
 		else if(rt[cnt]>0) 
 		{ 
 			rt[cnt]-=tq; 
 			time+=tq; 
 		} 
 		if(rt[cnt]==0 && flag==1) 
 		{ 
 			remain--; 
 			printf(" P[%d]\t\t%d\t %d\t \t%d\n",cnt+1,bt[cnt],time-at[cnt],time-at[cnt]-bt[cnt]); 
 			wait_time+=time-at[cnt]-bt[cnt]; 
 			turnaround_time+=time-at[cnt]; 
 			flag=0; 
 		}  
		if(cnt==n-1) 
 			cnt=0; 
 		else if(at[cnt+1]<=time) 
 			cnt++; 
 		else 
 			cnt=0; 
 	} 
 	Avg_wt=(float)wait_time/n;
 	Avg_tat=(float)turnaround_time/n;
 	printf("\nAverage Waiting Time= %f\n",Avg_wt); 
 	printf("Avg Turnaround Time = %f",Avg_tat);
 	mini[4]=Avg_wt;
 	mini[5]=Avg_tat;
 
 	for(i=0;i<n;i++){
 		bt[i]=b_t[i];
 		at[i]=a_t[i];
 	}
  
}


		//func for Shortest remaining time first algo
void srtf(int n,int at[],int bt[]){
	int temp[10],b_t[10],a_t[10];
    int i, smallest, count = 0, time,wt[10],tat[10];
    double wait_time = 0, turnaround_time = 0, end;
    float average_waiting_time, average_turnaround_time;
      
    for(i=0;i<n;i++){
 		b_t[i]=bt[i];
 		a_t[i]=at[i];
 	}

 
    for(i = 0; i < n; i++)
    {
        temp[i] = bt[i];   
    }
      
    bt[9] = 9999; 
	  
    for(time = 0; count != n; time++)
    {
        smallest = 9;
        for(i = 0; i < n; i++)
        {
        	if(at[i] <= time && bt[i] < bt[smallest] && bt[i] > 0)
            {
                smallest = i;
            }
        }
        bt[smallest]--;
        if(bt[smallest] == 0)
        {
            count++;
            end = time + 1;
            wait_time = wait_time + end - at[smallest] - temp[smallest];
            turnaround_time = turnaround_time + end - at[smallest];
			wt[smallest] = end - at[smallest] - temp[smallest];
            tat[smallest] = end - at[smallest]; 
        }
    }
    printf("\n~Process~\t~Burst Time~\t~WaitingTime~\t~TurnaroundTime~");
    for (i=0;i<n;i++){
      	printf("\np[%d]\t\t %d\t\t %d\t\t\t%d",i+1,temp[i],wt[i],tat[i]);
    }
    average_waiting_time = wait_time / n; 
    average_turnaround_time = turnaround_time / n;
    printf("\nAverage Waiting Time=%lf\n", average_waiting_time);
    printf("Average Turnaround Time=%lf\n", average_turnaround_time);
    mini[6]=average_waiting_time;
    mini[7]=average_turnaround_time;
	for(i=0;i<n;i++){
 	bt[i]=b_t[i];
	}
	for(i=0;i<n;i++){
 		at[i]=a_t[i];
	}
}


		//func for priority algo
void priority(int n, int bt[],int pr[]){
	int b_t[10],p[10],wt[10],tat[10],i,j,total=0,position,temp,avg_wt,avg_tat;
	
 	for(i=0;i<n;i++){
 		b_t[i]=bt[i];
 	}
 	

 	for(i=0;i<n;i++)
 	{
 		p[i]=i+1;
 	}
 	for(i=0;i<n;i++)
 	{
 		position=i;
 		for(j=i+1;j<n;j++)
 		{
 			if(pr[j]<pr[position])
 				position=j;
 		}
 		temp=pr[i];
 		pr[i]=pr[position];
 		pr[position]=temp;
 		temp=bt[i];
 		bt[i]=bt[position];
 		bt[position]=temp;
 		temp=p[i];
 		p[i]=p[position];
 		p[position]=temp;
 	}
 	wt[0]=0;
 	for(i=1;i<n;i++)
 	{
 		wt[i]=0;
 		for(j=0;j<i;j++)
 		{
 			wt[i]+=bt[j];
 		}
 		total+=wt[i];
 	}
 	avg_wt=total/n;
 	total=0; 
	printf("\n~Process~\t~BurstTime~\t~WaitingTime~\t~TurnaroundTime~\n");
 	for(i=0;i<n;i++)
 	{
 		tat[i]=bt[i]+wt[i];
 		total+=tat[i];
 		printf(" P[%d]\t\t %d\t\t %d\t\t\t%d\n",p[i],bt[i],wt[i],tat[i]);
 	}
 	avg_tat=total/n;
 	printf("\n\nAverage Waiting Time=%d",avg_wt);
 	printf("\nAverage Turnaround Time=%d\n",avg_tat);
 	mini[8]=avg_wt;
 	mini[9]=avg_tat;
 	for(i=0;i<n;i++){
 		bt[i]=b_t[i];
 	}
}


		//driver code
int main() 
{ 
 	int n,at[10],bt[10],pr[10],i,j,time_quantum,mini_wt,mini_tat;
 	char algo[5][20]={"FCFS","SJF","RR","SRTF","Priority"};
	 
	 //avg waiting times and turnaround times are stored in the array in the above order of algorithms	
	 		
    printf("Enter total number of processes(maximum 10):");			
    scanf("%d",&n);
 	printf("\nEnter Process arrival Times");
    for(i=0;i<n;i++)
    {
        printf("\nfor P[%d]:",i+1);
        scanf("%d",&at[i]);
    }
    
    
    printf("\nEnter Process Burst Times");
    for(i=0;i<n;i++)
    {
        printf("\nfor P[%d]:",i+1);
        
        scanf("%d",&bt[i]);
    }
    
    
  printf("\nEnter priorities of processes");
    for(i=0;i<n;i++)
    {
        printf("\nfor P[%d]:",i+1);
        
        scanf("%d",&pr[i]);
    }
    
    
printf("Enter Time Quantum for round robin:\n"); 
 scanf("%d",&time_quantum);
 
 	//calling all functions 
 	 
	  printf("\n\n\n-----------------***FOR FCFS SCHEDULING***-----------------\n\n\n");
     fcfs(n,at,bt);
     
       
	  printf("\n\n\n-----------------***FOR SJF SCHEDULING***-----------------\n\n\n");
	 sjf(n,bt);	 
    
	 printf("\n\n\n------------***FOR ROUND ROBIN SCHEDULING***------------------\n\n\n"); 
 	 rr(n,at,bt,time_quantum);
 	 
 	  printf("\n\n\n-----------------***FOR SRTF SCHEDULING***-----------------\n\n\n");
	 srtf(n,at,bt);

	 
	 printf("\n\n\n-----------------***FOR PRIORITY SCHEDULING***-----------------\n\n\n");
	 priority(n,bt,pr);

     /* 
	 //code to print 'mini' array
	 
	 printf("\n\n\n");
    for(i=0;i<10;i++){
    	printf("%f,",mini[i]);
	}*/
     
    
    mini_wt=0;
    mini_tat=1;
    
    //loop to find the minimum avg waiting and turn around times
    for(i=2;i<10;i+=2)
    {
      if (mini[i]<mini[mini_wt])
      {
        mini_wt=i;		// index of minimum avg waiting time is stored in 'mini_wt'
        
      }
      if(mini[i+1]<mini[mini_tat])
      {
        mini_tat=i+1;		// index of minimum avg turnaround time is stored in 'mini_tat'
        
      }
    }
    printf("\n_____________________________________________________________________");
    //     condition to check if the algo having min avg waiting time also having the min avg turnaroundtime
    if(mini[mini_tat]==mini[mini_wt+1] || mini_wt+1==mini_tat)
    {
      printf("\n\n%s IS THE EFFICIENT ALGORITHM IN THIS CASE\n(HAVING MINIMUM AVERAGE WAITING TIME AND AVERAGE TURN AROUND TIME)\n",(algo[mini_wt/2]));
    }
    
    //     if different algorithms having min avg waiting time and min avg turnaround time, print their names respectively
    else
    {
      printf("\n\n%s IS THE EFFICIENT ALGORITHM HAVING MINIMUM AVERAGE WAITING TIME\n",(algo[mini_wt/2]));
      printf("%s IS THE EFFICIENT ALGORITHM HAVING MINIMUM AVERAGE TURN AROUND TIME\n\n",(algo[(mini_tat-1)/2]));
    }
    
    printf("_____________________________________________________________________"); 
    
 return 0; 
}
